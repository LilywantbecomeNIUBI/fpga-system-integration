"""Offline known-laser-pose grid mapping; not a localization/SLAM backend.

Ray traversal reuses the pinned MIT PythonRobotics implementation. Python 3.6+.
Coordinates: x right, y up, yaw CCW, units mm/radians; storage is y*size+x.
"""
import math
from pathlib import Path
import sys

_VENDOR = Path(__file__).resolve().parents[1] / 'vendor/mapping/PythonRobotics'
sys.path.insert(0, str(_VENDOR))
from bresenham import bresenham


class GridConfig:
    def __init__(self, size=256, resolution_mm=50, origin_x_mm=-6400,
                 origin_y_mm=-6400, min_range_mm=100, max_range_mm=25000,
                 angle_sign=1):
        if size < 2 or size > 256 or size & (size-1):
            raise ValueError('size must be a power of two in [2,256]')
        if not all(math.isfinite(v) for v in (resolution_mm, origin_x_mm,
                   origin_y_mm, min_range_mm, max_range_mm)):
            raise ValueError('Non-finite grid configuration')
        if resolution_mm <= 0 or not 0 < min_range_mm < max_range_mm or angle_sign not in (-1, 1):
            raise ValueError('Invalid resolution, range or angle sign')
        self.size, self.resolution_mm = size, resolution_mm
        self.origin_x_mm, self.origin_y_mm = origin_x_mm, origin_y_mm
        self.min_range_mm, self.max_range_mm = min_range_mm, max_range_mm
        self.angle_sign = angle_sign

    def cell(self, x, y):
        return (math.floor((x-self.origin_x_mm)/self.resolution_mm),
                math.floor((y-self.origin_y_mm)/self.resolution_mm))


def clip_ray(start, end, size):
    """Clip an in-grid origin to the grid edge; a clipped endpoint is not a hit."""
    if not all(0 <= c < size for c in start):
        raise ValueError('Laser origin outside fixed map; recenter explicitly')
    if all(0 <= c < size for c in end):
        return end, True
    t = 1.0
    for a, b in zip(start, end):
        if b < 0:
            t = min(t, (0-a)/(b-a))
        elif b >= size:
            t = min(t, (size-1-a)/(b-a))
    return tuple(max(0, min(size-1, math.floor(a+t*(b-a)+.5)))
                 for a, b in zip(start, end)), False


def scan_to_rays(points, config, laser_pose=(0., 0., 0.)):
    """Return (sx,sy,ex,ey,hit) rays and explicit rejection/clipping counts.

    pose is the LASER pose, not the chassis pose. No timing/deskew is inferred.
    Unknown/zero returns are skipped, never interpreted as free-space beams.
    """
    if len(laser_pose) != 3 or not all(math.isfinite(v) for v in laser_pose):
        raise ValueError('A finite laser pose (x_mm,y_mm,yaw_rad) is required')
    px, py, yaw = laser_pose
    start = config.cell(px, py)
    if not all(0 <= c < config.size for c in start):
        raise ValueError('Laser origin outside map')
    stats = dict(points=0, invalid=0, clipped=0, rays=0)
    rays = []
    for point in points:
        stats['points'] += 1
        if len(point) != 3 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in point):
            stats['invalid'] += 1
            continue
        angle, distance, strength = point
        if not (0 <= angle < 360 and config.min_range_mm <= distance <= config.max_range_mm
                and 0 < strength <= 255):
            stats['invalid'] += 1
            continue
        theta = yaw + config.angle_sign*math.radians(angle)
        end = config.cell(px+distance*math.cos(theta), py+distance*math.sin(theta))
        end, hit = clip_ray(start, end, config.size)
        rays.append((*start, *end, int(hit)))
        stats['clipped'] += not hit
    stats['rays'] = len(rays)
    return rays, stats


class OccupancyGrid:
    """9-bit cell: observed flag plus saturated signed 8-bit evidence score.

    Evidence steps (-4 free/+12 hit) are tunable engineering defaults, not a
    calibrated probability model. Observed zero remains distinct from unknown.
    """
    def __init__(self, size=256):
        self.size = size
        self.scores = [0]*(size*size)
        self.observed = bytearray(size*size)
        self.updates = 0

    def update(self, ray):
        sx, sy, ex, ey, hit = ray
        if hit not in (0, 1) or not all(isinstance(c, int) and 0 <= c < self.size for c in ray[:4]):
            raise ValueError('Invalid ray command')
        cells = bresenham((sx, sy), (ex, ey))
        for x, y in cells:
            i = y*self.size+x
            step = 12 if hit and x == ex and y == ey else -4
            self.scores[i] = max(-127, min(127, self.scores[i]+step))
            self.observed[i] = 1
        self.updates += len(cells)

    def packed(self):
        return [(int(seen)<<8) | (value & 255)
                for seen, value in zip(self.observed, self.scores)]

    def summary(self):
        return dict(updates=self.updates, observed=sum(self.observed),
                    occupied=sum(v > 0 for v in self.scores),
                    free=sum(v < 0 for v in self.scores),
                    observed_neutral=sum(s and v == 0 for s, v in zip(self.observed, self.scores)))
